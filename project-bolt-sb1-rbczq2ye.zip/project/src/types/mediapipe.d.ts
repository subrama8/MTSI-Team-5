// MediaPipe type definitions for global window object
declare global {
  interface Window {
    FaceMesh: any;
  }
}

export {};